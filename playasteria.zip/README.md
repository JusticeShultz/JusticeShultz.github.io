# Justice Shultz

### Oh hey look stuff actually shows up!

Check out my GitHub while you're here, it's kinda neat: https://github.com/JusticeShultz/
